andaman_nicobar_island_lok_sabha_centers= [
    "Andaman and Nicobar Islands"
]
andhra_pradesh_lok_sabha_centers = [
    "Araku (ST)", "Srikakulam", "Vizianagaram", "Visakhapatnam", "Anakapalle", "Kakinada",
    "Amalapuram (SC)", "Rajahmundry", "Narasapuram", "Eluru", "Machilipatnam", "Vijayawada",
    "Guntur", "Narasaraopet", "Bapatla (SC)", "Ongole", "Nandyal", "Kurnool", "Anantapur",
    "Hindupur", "Kadapa", "Nellore", "Tirupati (SC)", "Rajampet","Chittoor (SC)"
]
arunachal_pradesh_lok_sabha_centres= [
    "Arunachal West", "Arunachal East"
]
assam_lok_sabha_centres= [
    "Kokrajhar (ST)", "Dhubri", "Barpeta", "Darrang–Udalguri", "Guwahati", "Diphu (ST)",
    "Karimganj", "Silchar (SC)", "Nowgong", "Kaziranga","Sonitpur", "Lakhimpur", "Dibrugarh", "Jorhat"
]
bihar_lok_sabha_centers =[
    "Araria", "Arrah", "Aurangabad", "Banka", "Begusarai",
    "Bhagalpur", "Buxar", "Darbhanga", "Gaya", "Gopalganj","Hajipur",
    "Jahanabad", "Jamui", "Jhanjharpur", "Karakat", "Katihar",
    "Khagaria", "Kishanganj", "Madhepura","Madhubani","Maharajganj","Munger",
    "Muzaffarpur", "Nalanda", "Nawada", "Paschim Champaran", "Pataliputra","Patna Sahib",
    "Purnia", "Purvi Champaran", "Samastipur", "Saran", "Sasaram", "Sheohar","Sitamarhi",
    "Siwan", "Supaul", "Ujiarpur","Vaishali", "Valmiki Nagar"
]
chandigarh_lok_sabha_centers=[
    "Chndigarh"
]
chhattisgarh_lok_sabha_centers = [
    "Bastar", "Bilaspur", "Durg", "Raigarh", "Rajnandgaon",
    "Korba", "Surguja", "Janjgir-Champa", "Mahasamund", "Dhamtari"
]
Dadra_nagar_haveli_and_daman_and_diu_lok_sabha_centers= [
    "Daman and Diu", "Dadra and Nagar Haveli"
]
Delhi_lok_sabha_centers =[
    "Chandni Chowk", "East Delhi", "New Delhi",
    "North East Delhi", "North West Delhi (SC)", "South Delhi", "West Delhi"
]
goa_lok_sabha_centers = [
    "North Goa", "South Goa"
]
gujarat_lok_sabha_centers = [
    "Kachchh (SC)", "Banaskantha", "Patan", "Mahesana", "Sabarkantha", "Gandhinagar", "Ahmedabad East",
    "Ahmedabad West (SC)", "Surendranagar", "Rajkot", "Porbandar", "Jamnagar", "Junagadh", "Amreli",
    "Bhavnagar", "Anand", "Kheda", "Panchmahal", "Dahod (ST)", "Vadodara", "Chhota Udaipur (ST)",
    "Bharuch", "Bardoli (ST)", "Surat", "Navsari", "Valsad (ST)"
]
haryana_lok_sabha_centers = [
    "Ambala", "Bhiwani-Mahendragarh", "Faridabad", "Gurgaon", "Hisar",
    "Karnal", "Kurukshetra", "Panchkula", "Rohtak", "Sonipat"
]
himachal_pradesh_lok_sabha_centers = [
    "Kangra","Hamirpur", "Mandi", "Shimla"
]
jammu_and_kashmir_lok_sabha_centers= [
    "Baramulla", "Srinagar", "Anantnag-Rajouri", "Udhampur", "Jammu"
]
jharkhand_lok_sabha_centers = [
    "Rajmahal","Dumka", "Godda", "Chatra", "Koderma", "Giridih", "Dhanbad", "Ranchi", "Jamshedpur",
    "Singhbhum", "Khunti", "Lohardanga", "Palamu", "Hazaribagh"
]
karnataka_lok_sabha_centers= [
    "Chikkodi", "Belgaum", "Bagalkot", "Bijapur (SC)", "Gulbarga (SC)", "Raichur (ST)", "Bidar",
    "Koppal", "Bellary (ST)", "Haveri", "Dharwad", "Uttara Kannada", "Davanagere", "Shimoga",
    "Udupi Chikmagalur", "Hassan", "Dakshina Kannada", "Chitradurga (SC)", "Tumkur", "Mandya",
    "Mysore", "Chamarajanagar (SC)", "Bangalore Rural", "Bangalore North","Bangalore Central",
    "Bangalore South", "Chikballapur", "Kolar (SC)"  
]
kerala_lok_sabha_centers= [
    "Kasaragod", "Kannur", "Vatakara", "Wayanad", "Kozhikode", "Malappuram", "Ponnani", "Palakkad",
    "Alathur (SC)", "Thrissur", "Chalakudy", "Ernakulam", "Idukki", "Kottayam", "Alappuzha",
    "Mavelikara (SC)", "Pathanamthitta", "Kollam", "Attingal", "Thiruvananthapuram"
]
ladakh_lok_sabha_centers = [
    "Ladakh"
]
lakshadeep_lok_sabha_centers = [
    "Lakshadeep"
]
madhya_pradesh_lok_sabha_centres = [
    "Morena", "Bhind (SC)", "Gwalior", "Guna", "Sagar", "Tikamgarh", "Damoh", "Satna", "Rewa", "Sidhi",
    "Shahdol", "Jabalpur", "Mandla", "Balaghat", "Chhindwara", "Hoshangabad", "Narmadapuram", "Vidisha",
    "Bhopal", "Rajgarh", "Dewas","Ujjain", "Mandsaur", "Ratlam", "Dhar", "Indore", "Khargone","Khandwa",
    "Betul"
]
maharashtra_lok_sabha_centers = [
    "Nandurbar (ST)", "Dhule", "Jalgaon", "Raver", "Buldhana", "Akola", "Amravati (SC)", "Wardha",
    "Ramtek (SC)", "Nagpur", "Bhandara-Gondiya", "Gadchiroli-Chimur (ST)", "Chandrapur", "Yavatmal-Washim",
    "Hingoli", "Nanded", "Parbhani", "Jalna", "Aurangabad", "Dindori (ST)", "Nashik", "Palghar (ST)",
    "Bhiwandi", "Kalyan", "Thane", "Mumbai North", "Mumbai North West", "Mumbai North East", "Mumbai North Central",
    "Mumbai South Central", "Mumbai South", "Raigad", "Maval", "Pune", "Baramati", "Shirur", "Ahmednagar",
    "Shirdi (SC)", "Beed", "Osmanabad", "Latur (SC)", "Solapur (SC)", "Madha", "Sangli",
    "Satara", "Ratnagiri-Sindhudurg", "Kolhapur", "Hatkanangle"
]
manipur_lok_sabha_centres =[
    "Inner Manipur", "Outer Manipur"
]
meghalaya_lok_sabha_centers = [
    "Shillong", "Tura"
]
mizoram_lok_sabha_centers = [
    "Mizoram"
]
nagaland_lok_sabha_centers = [
    "Ngaland"
]
odisha_lok_sabha_centers = [
    "Aska", "Balasore", "Bargarh", "Berhampur", "Bhadrak", "Bhubaneswar", "Bolangir",
    "Cuttack", "Dhenkanal", "Jagatsinghpur", "Jajpur", "Kalahandi", "Kandhamal", "Kendrapara", "Keonjhar",
    "Koraput", "Mayurbhanj", "Nabarangpur", "Puri", "Sambalpur", "Sundargarh"

]
puducherry_lok_sabha_centres = [
    "Puducherry"
]
punjab_lok_sabha_centers = [
    "Gurdaspur", "Amritsar", "Khadoor Sahib", "Jalandhar", "Hoshiarpur", "Anandpur Sahib", "Ludhiana",
    "Fatehgarh Sahib", "Faridkot", "Firozpur","Bathinda", "Sangrur", "Patiala"
]
rajasthan_lok_sabha_centers = [
    "Ganganagar (SC)", "Bikaner (SC)", "Churu", "Jhunjhunu", "Sikar", "Jaipur Rural", "Jaipur",
    "Alwar", "Bharatpur (SC)", "Karauli-Dholpur (SC)", "Dausa (ST)", "Tonk-Sawai Madhopur",
    "Ajmer (SC)", "Nagaur", "Pushkar", "Pali", "Jodhpur", "Barmer", "Jalore", "Udaipur (ST)",
    "Banswara (ST)", "Chittorgarh", "Rajasamand", "Bhilwara","Kota"
]
sikim_lok_sabha_centers = [
    "Sikim"
]
tamil_nadu_lok_sabha_centers = [
    "Thiruvallur (SC)", "Chennai North", "Chennai South", "Chennai Central", "Sriperumbudur",
    "Kanchipuram (SC)", "Arakkonam", "Vellore", "Krishnagiri", "Dharmapuri", "Tiruvannamalai",
    "Arni", "Villupuram (SC)", "Kallakurichi", "Salem", "Namakkal", "Erode", "Tiruppur", "Nilgiris (SC)",
    "Coimbatore", "Pollachi", "Dindigul", "Karur", "Tiruchirappalli", "Perambalur", "Cuddalore", "Chidambaram (SC)",
    "Mayiladuthurai", "Nagapattinam (SC)", "Thanjavur", "Sivaganga", "Madurai", "Theni", "Virudhunagar",
    "Ramanathapuram", "Tuticorin", "Tenkasi (SC)", "Tirunelveli", "Kanyakumari"
]
telengana_lok_sabha_centres= [
    "Adilabad (ST)", "Peddapalle (SC)", "Karimnagar", "Nizamabad", "Zahirabad", "Medak",
    "Malkajgiri", "Secunderabad", "Hyderabad", "Chevella", "Mahbubnagar", "Nagarkurnool (SC)",
    "Nalgonda", "Bhongir", "Warangal (SC)", "Mahabubabad (ST)","Khammam"
]
tripura_lok_sabha_centres = [
    "Tripura West", "Tripura East"
]
uttar_pradesh_lok_sabha_centers = [
    "Saharanpur", "Kairana", "Muzaffarnagar", "Bijnor", "Nagina (SC)", "Moradabad", "Rampur",
    "Sambhal", "Amroha", "Meerut", "Baghpat", "Ghaziabad", "Gautam Buddha Nagar", "Bulandshahr (SC)","Aligarh",
    "Hathras (SC)", "Mathura", "Agra (SC)", "Fatehpur Sikri", "Firozabad", "Mainpuri", "Etah", "Badaun",
    "Aonla", "Bareilly", "Pilibhit", "Shahjahanpur (SC)", "Kheri", "Dhaurahra", "Sitapur",
    "Hardoi", "Misrikh (SC)", "Unnao", "Mohanlalganj (SC)", "Lucknow", "Rae Bareli", "Amethi",
    "Sultanpur", "Pratapgarh", "Farrukhabad", "Etawah (SC)", "Kannauj", "Kanpur Urban", "Akbarpur",
    "Jalaun (SC)", "Jhansi", "Hamirpur", "Banda", "Fatehpur", "Kaushambi (SC)", "Phulpur", "Allahabad",
    "Barabanki (SC)", "Faizabad", "Ambedkar Nagar", "Bahraich (SC)", "Kaiserganj", "Shrawasti",
    "Gonda", "Domariyaganj", "Basti", "Sant Kabir Nagar", "Maharajganj", "Gorakhpur", "Kushinagar",
    "Deoria", "Bansgaon (SC)", "Lalganj (SC)", "Azamgarh", "Ghosi", "Salempur", "Ballia",  "Jaunpur",
    "Machhlishahr (SC)", "Ghazipur", "Chandauli", "Varanasi", "Bhadohi", "Mirzapur","Robertsganj (SC)"
]
uttarakhand_lok_sabha_centres = [
    "Tehri Garhwal", "Garhwal", "Almora", "Nainital-Udhamsingh Nagar", "Haridwar"
]
west_bengal_lok_sabha_centers= [
    "Cooch Behar (SC)", "Alipurduar (ST)", "Jalpaiguri (SC)", "Darjeeling", "Raiganj", "Balurghat",
    "Malda North", "Malda South", "Jangipur", "Baharampur", "Murshidabad", "Krishnanagar", "Ranaghat (SC)",
    "Bangaon (SC)", "Barakpur", "Dum Dum", "Barasat", "Basirhat", "Jaynagar", "Mathurapur (SC)","Diamond Harbour",
    "Jadavpur", "Kolkata South", "Kolkata North", "Howrah", "Uluberia", "Shrirampur", "Hooghly",
    "Arambagh (SC)", "Tamluk", "Kanti", "Ghatal", "Jhargram (ST)", "Midnapore", "Purulia",
    "Bankura", "Bishnupur (SC)", "Burdwan East (SC)", "Burdwan-Durgapur",
    "Asansol","Bolpur (SC)", "Birbhum"
]